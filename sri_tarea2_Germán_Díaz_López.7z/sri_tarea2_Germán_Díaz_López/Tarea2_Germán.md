# Tarea 2  
  
![alt text](instalacion_servidor_dhcp.png)
Aqui empezamos a instalar el servidor dhcp.  
![alt text](<Captura de pantalla 2024-10-07 120417.png>)
 Aqui emepezamos a configurar el archivo dhcpd.conf  
 ![alt text](configuracion_red_debian.png)
 En esta imagen configuramos la red de la maquina debian.  
 ![alt text](reserva_ubuntu.png) 
 En esta imagen se pude  oserbar que  la reserva de ip para la maquina ubuntu  
 ![alt text](ip_ubuntu_asignada.png)  
 En esta imagen  se puede ver la comprobacion de  que la ip reservada ha sido asignada  
 ![alt text](comprobacion_ping.png)
 Por ultimo se puede observar que las dos maquinas se ven a traves de un ping
